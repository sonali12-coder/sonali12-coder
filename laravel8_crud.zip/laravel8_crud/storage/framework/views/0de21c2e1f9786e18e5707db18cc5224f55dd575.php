<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Laravel 8.0 CRUD Application</title>
        <link rel="stylesheet" href="<?php echo e('assets/css/bootstrap.css'); ?>">
    </head>
<body class="bg-light">
	<div class="p-3 mb-2 bg-dark text-white">
		<div class="container">
			<div class="h3">Laravel 8.0 CRUD Application</div>
		</div>
	</div>
	<div class="container">
			<div class="row">
				<div class="col-md-12 mb-3" style="margin-left: 639px;">
					<a href="<?php echo e('articles/add'); ?>" class="btn btn-primary">ADD</a>
				</div>
				<?php if(Session::has('msg')): ?>
				<div class="col-md-12">
					<div class="alret alret-success"><?php echo e(Session::get('msg')); ?></div>
				</div>
				<?php endif; ?>
				<?php if(Session::has('errorMsg')): ?>
				<div class="col-md-12">
					<div class="alret alret-danger"><?php echo e(Session::get('errorMsg')); ?></div>
				</div>
				<?php endif; ?>
			</div>
			<div class="col-md-12">
				<div class="card">
				<div class="card-header"><h5>Station/List</h5></div>
				<div class="card-body">
					<table class="table">
						<thead class="thead-dark bg-dark text-white">
						<tr>
							<th>ID</th>
							<th>NAME</th>
							<th>DESCRIPTION</th>
							<th>CREATED</th>
							<th width="100">EDIT</th>
							<th width="100">DELETE</th>
						</tr>
						</thead>
						<?php if($articles): ?>
						  <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($article->id); ?></td>
							<td><?php echo e($article->name); ?></td>
							<td><?php echo e($article->description); ?></td>
							<td><?php echo e($article->created_at); ?></td>
							<td><a href="<?php echo e(url('articles/edit/'.$article->id)); ?>" class="btn btn-primary">Edit</a></td>
							<td><a href="#" onclick="deleteArticle(<?php echo e($article->id); ?>);" class="btn btn-danger">Delete</a></td>
						</tr>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<tr>
							<td colspan="6">File not added yet.</td>
						</tr>
						<?php endif; ?>
					</table>
				</div>
			   </div>
			</div>
			
	</div>



</body>
</html>
<script type="text/javascript">
	function deleteArticle(id){
		if(confirm('Are u sure you want to delete?')){
			window.location.href='<?php echo e(url('articles/delete')); ?>/'+id;
		}
	}
</script>
<?php /**PATH C:\xampp\htdocs\laravel8_crud\resources\views/list.blade.php ENDPATH**/ ?>